package com.newrelic.instrumentation.labs.ktor.server;

import com.newrelic.agent.bridge.AgentBridge;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TracedMethod;
import com.newrelic.api.agent.Transaction;
import com.newrelic.api.agent.TransactionNamePriority;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.Nullable;

import java.util.logging.Level;

public class NRFunction1RoutingWrapper<A,B> implements Function1<A,B> {

    private final Function1<A,B> wrapped;
    @Nullable
    private String path =  null;
    @Nullable
    private String method = null;

    private static boolean isTransformed = false;

    public NRFunction1RoutingWrapper(Function1<A,B> wrapped, @Nullable String path, @Nullable String theMethod) {
        NewRelic.getAgent().getLogger().log(Level.FINE,"Creating NRFunction1RoutingWrapper, path = {0}, method = {1}, wrapped = {2}",path, theMethod, wrapped);
        this.wrapped = wrapped;
        this.path = path;
        this.method = theMethod;
        if(!isTransformed) {
            AgentBridge.instrumentation.retransformUninstrumentedClass(getClass());
            isTransformed = true;
        }
    }

    @Override
    @Trace(dispatcher = true)
    public B invoke(A a) {
        NewRelic.getAgent().getLogger().log(Level.FINE,"Call to NRFunction1RoutingWrapper.invoke({0}), a is of type {4}, path = {1}, method = {2}, wrapped = {3}",a, path, method, wrapped, a.getClass());
        Transaction transaction = NewRelic.getAgent().getTransaction();
        if(!transaction.isWebTransaction()) {
            transaction.convertToWebTransaction();
        }
        TracedMethod traced = NewRelic.getAgent().getTracedMethod();
        if(method != null) {
            String routeString = path != null ? path + " (" + method + ")" : "(" + method + ")";
            traced.addCustomAttribute("route", routeString);
            traced.setMetricName("Custom","Ktor","Routing","Wrapper", method);
            transaction.setTransactionName(TransactionNamePriority.CUSTOM_LOW,true, "Ktor-Server", "Routing", routeString);
        }
        B b=  wrapped.invoke(a);
        NewRelic.getAgent().getLogger().log(Level.FINE,"Return from NRFunction1RoutingWrapper.invoke({0}), result is {1} of type {2}",a, b, b.getClass());
        return b;
    }
}
