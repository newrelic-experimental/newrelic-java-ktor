package com.newrelic.instrumentation.labs.ktor.server;

import io.ktor.routing.Route;

import java.util.LinkedHashMap;

public class KtorServerUtils {

    private static final LinkedHashMap<Route, String> routingPaths = new LinkedHashMap<>();
    private static final LinkedHashMap<Route, String> routingMethods = new LinkedHashMap<>();

    public static void addRoute(Route route, String path, String method) {
        if(!routingPaths.containsKey(route)) {
            routingPaths.put(route, path);
        }
        if(!routingMethods.containsKey(route)) {
            routingMethods.put(route, method);
        }
    }

    public static String getRouteTransactionName(Route route) {
        String path = routingPaths.get(route);
        String method = routingMethods.get(route);
        if(path != null) {
            return method != null ? path + "(" + method + ")" : path + "(UnknownMethod)";
        } else if(method != null) {
            return "UnknownPath (" + method + ")";
        }
        return null;
    }
}
