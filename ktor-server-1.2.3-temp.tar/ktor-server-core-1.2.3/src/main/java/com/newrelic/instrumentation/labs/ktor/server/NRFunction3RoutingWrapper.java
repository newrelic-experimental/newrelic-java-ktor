package com.newrelic.instrumentation.labs.ktor.server;

import com.newrelic.agent.bridge.AgentBridge;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TracedMethod;
import com.newrelic.api.agent.Transaction;
import com.newrelic.api.agent.TransactionNamePriority;

import kotlin.jvm.functions.Function3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NRFunction3RoutingWrapper<A,B,C,D> implements Function3<A,B,C,D> {

	@NotNull
	private final Function3<A,B,C,D> delegate;
	@Nullable
	private String path = null;
	@Nullable
	private String method = null;
	private static boolean isTransformed = false;
		
	public NRFunction3RoutingWrapper( @NotNull Function3<A, B, C,D> d, @Nullable String path, @Nullable String method) {
		delegate = d;
		this.path = path;
		this.method = method;
		if(!isTransformed) {
			AgentBridge.instrumentation.retransformUninstrumentedClass(getClass());
			isTransformed = true;
		}
	}

	@Override
	@Trace(dispatcher = true)
	public D invoke(A arg0, B arg1, C arg2) {
		TracedMethod traced = NewRelic.getAgent().getTracedMethod();
		if(method != null) {
			String tmpString = path;
			if(path != null) {
				int index = path.indexOf('?');
				if(index != -1) {
					tmpString = path.substring(0,index);
				} else {
					tmpString = path;
				}
			}
			String routeString = tmpString != null ? tmpString + " (" + method + ")" : "(" + method + ")";
			traced.addCustomAttribute("route", routeString);
			traced.setMetricName("Custom","Ktor","RoutingMethod","Wrapper",method);
        }
		return delegate.invoke(arg0, arg1, arg2);
	}

}
