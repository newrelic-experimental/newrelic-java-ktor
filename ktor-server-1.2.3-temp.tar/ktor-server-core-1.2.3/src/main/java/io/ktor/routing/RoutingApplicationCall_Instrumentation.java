package io.ktor.routing;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.TransactionNamePriority;
import com.newrelic.api.agent.weaver.Weave;

import java.util.logging.Level;

@Weave(originalName = "io.ktor.routing.RoutingApplicationCall")
public class RoutingApplicationCall_Instrumentation {

    public RoutingApplicationCall_Instrumentation(io.ktor.application.ApplicationCall call, io.ktor.routing.Route route, io.ktor.request.ApplicationReceivePipeline requestPipeline, io.ktor.response.ApplicationSendPipeline sendPipeline, io.ktor.http.Parameters parameters) {
        NewRelic.getAgent().getLogger().log(Level.FINE, "RoutingApplicationCall.<init>, call - {0}, route - {1}, requestPipeline - {2}, sendPipeline - {3}, parameters - {4}", call, route, requestPipeline, sendPipeline, parameters);
        NewRelic.getAgent().getTransaction().setTransactionName(TransactionNamePriority.CUSTOM_HIGH, false, "KtorServerRouting", route.toString());
    }
}
